"""
FinTrack India — Flask Backend
Serves the frontend and provides a REST API backed by SQLite.

Run with:  python app.py
Open:      http://localhost:5000
"""

import sqlite3
import os
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from datetime import datetime

# ─────────────────────────────────────────────
# App setup
# ─────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, "fintrack.db")

app = Flask(__name__, static_folder=BASE_DIR)
CORS(app)  # allow browser fetch() from the same host


# ─────────────────────────────────────────────
# Database helpers
# ─────────────────────────────────────────────
def get_db():
    """Open a database connection with row_factory for dict-like rows."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create the transactions table if it doesn't exist."""
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                desc      TEXT    NOT NULL,
                amount    REAL    NOT NULL CHECK(amount > 0),
                category  TEXT    NOT NULL,
                date      TEXT    NOT NULL,
                type      TEXT    NOT NULL CHECK(type IN ('income', 'expense')),
                created_at TEXT   DEFAULT (datetime('now','localtime'))
            )
        """)
        conn.commit()
    print(f"[OK] Database ready -> {DB_PATH}")


# ─────────────────────────────────────────────
# Serve the frontend
# ─────────────────────────────────────────────
@app.route("/")
def index():
    return send_from_directory(BASE_DIR, "index.html")


@app.route("/<path:filename>")
def static_files(filename):
    return send_from_directory(BASE_DIR, filename)


# ─────────────────────────────────────────────
# API — Transactions
# ─────────────────────────────────────────────

@app.route("/api/transactions", methods=["GET"])
def get_transactions():
    """Return all transactions ordered newest-first."""
    category = request.args.get("category")   # optional filter
    tx_type  = request.args.get("type")        # optional filter

    query  = "SELECT * FROM transactions WHERE 1=1"
    params = []

    if category and category != "all":
        query  += " AND category = ?"
        params.append(category)
    if tx_type and tx_type != "all":
        query  += " AND type = ?"
        params.append(tx_type)

    query += " ORDER BY date DESC, created_at DESC"

    with get_db() as conn:
        rows = conn.execute(query, params).fetchall()

    return jsonify([dict(r) for r in rows])


@app.route("/api/transactions", methods=["POST"])
def add_transaction():
    """Add a new transaction.

    Expected JSON body:
        { "desc": str, "amount": float, "category": str,
          "date": "YYYY-MM-DD", "type": "income"|"expense" }
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "No JSON body provided"}), 400

    # Validate required fields
    required = ["desc", "amount", "category", "date", "type"]
    missing  = [f for f in required if f not in data or data[f] == ""]
    if missing:
        return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 400

    if data["type"] not in ("income", "expense"):
        return jsonify({"error": "type must be 'income' or 'expense'"}), 400

    try:
        amount = float(data["amount"])
        if amount <= 0:
            raise ValueError
    except ValueError:
        return jsonify({"error": "amount must be a positive number"}), 400

    # Validate date format
    try:
        datetime.strptime(data["date"], "%Y-%m-%d")
    except ValueError:
        return jsonify({"error": "date must be in YYYY-MM-DD format"}), 400

    with get_db() as conn:
        cur = conn.execute(
            "INSERT INTO transactions (desc, amount, category, date, type) VALUES (?,?,?,?,?)",
            (data["desc"].strip(), amount, data["category"], data["date"], data["type"])
        )
        conn.commit()
        new_id = cur.lastrowid
        row = conn.execute("SELECT * FROM transactions WHERE id = ?", (new_id,)).fetchone()

    return jsonify(dict(row)), 201


@app.route("/api/transactions/<int:tx_id>", methods=["DELETE"])
def delete_transaction(tx_id):
    """Delete a transaction by ID."""
    with get_db() as conn:
        existing = conn.execute("SELECT id FROM transactions WHERE id = ?", (tx_id,)).fetchone()
        if not existing:
            return jsonify({"error": "Transaction not found"}), 404
        conn.execute("DELETE FROM transactions WHERE id = ?", (tx_id,))
        conn.commit()

    return jsonify({"message": "Transaction deleted", "id": tx_id})


# ─────────────────────────────────────────────
# API — Summary
# ─────────────────────────────────────────────

@app.route("/api/summary", methods=["GET"])
def get_summary():
    """Return aggregated income, expense, savings, and category breakdown."""
    with get_db() as conn:
        totals = conn.execute("""
            SELECT
                COALESCE(SUM(CASE WHEN type='income'  THEN amount ELSE 0 END), 0) AS total_income,
                COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END), 0) AS total_expense,
                COUNT(*) AS transaction_count
            FROM transactions
        """).fetchone()

        categories = conn.execute("""
            SELECT category, SUM(amount) AS total
            FROM transactions
            WHERE type='expense'
            GROUP BY category
            ORDER BY total DESC
        """).fetchall()

        monthly = conn.execute("""
            SELECT strftime('%Y-%m', date) AS month,
                   SUM(CASE WHEN type='expense' THEN amount ELSE 0 END) AS expenses,
                   SUM(CASE WHEN type='income'  THEN amount ELSE 0 END) AS income
            FROM transactions
            GROUP BY month
            ORDER BY month ASC
        """).fetchall()

    t = dict(totals)
    return jsonify({
        "total_income":       t["total_income"],
        "total_expense":      t["total_expense"],
        "net_savings":        t["total_income"] - t["total_expense"],
        "transaction_count":  t["transaction_count"],
        "category_breakdown": [dict(r) for r in categories],
        "monthly_trend":      [dict(r) for r in monthly],
    })


# ─────────────────────────────────────────────
# Health check
# ─────────────────────────────────────────────

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "app": "FinTrack India", "db": DB_PATH})


# ─────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    print("[INFO] FinTrack India backend starting...")
    print("[INFO] Open http://localhost:5000 in your browser")
    app.run(debug=True, port=5000)
/* ===========================
   FinTrack India — app.js
   Backend-connected version
   API Base: /api
   =========================== */
'use strict';

// ===== CONFIG =====
const API = '/api';

// ===== STATE =====
let transactions = [];   // loaded from server
let currentType = 'expense';
let currentRegime = 'new';
let charts = {};

// ===== UTILITIES =====
const fmt = (n) => '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 0 });
const fmtDec = (n, d = 2) => '₹' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: d, maximumFractionDigits: d });

function showToast(msg, type = 'success') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast show ${type}`;
  setTimeout(() => t.classList.remove('show'), 3000);
}

function formatDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

const CATEGORY_ICONS = {
  'Food & Dining': '🍕', 'Transport': '🚗', 'Shopping': '🛍️',
  'Entertainment': '🎬', 'Health': '💊', 'Education': '📚',
  'Utilities': '💡', 'Rent': '🏠', 'Salary': '💼',
  'Freelance': '💻', 'Investment': '📈', 'Other': '📦'
};

// ===== API HELPERS =====
async function apiFetch(path, options = {}) {
  try {
    const res = await fetch(API + path, {
      headers: { 'Content-Type': 'application/json' },
      ...options
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Server error');
    return data;
  } catch (err) {
    showToast(err.message || 'Network error', 'error');
    throw err;
  }
}

async function loadTransactions() {
  try {
    transactions = await apiFetch('/transactions');
    renderTransactions();
    updateDashboard();
  } catch (_) { }
}

// ===== NAVIGATION =====
document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    const tab = btn.dataset.tab;
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + tab).classList.add('active');
    const titles = {
      dashboard: 'Dashboard', expenses: 'Expense Tracker',
      prediction: 'Expense Prediction', tax: 'Tax Calculator', investment: 'Investment Forecasting'
    };
    document.getElementById('page-title').textContent = titles[tab] || tab;
    if (tab === 'dashboard') updateDashboard();
    if (tab === 'prediction') updateInsights();
    document.getElementById('sidebar').classList.remove('open');
  });
});

document.getElementById('menu-toggle').addEventListener('click', () => {
  document.getElementById('sidebar').classList.toggle('open');
});

// ===== DATE HEADER =====
(function setDateHeader() {
  const now = new Date();
  document.getElementById('page-date').textContent =
    now.toLocaleDateString('en-IN', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
})();

// ===== EXPENSE FORM =====
document.getElementById('exp-date').valueAsDate = new Date();

document.getElementById('type-expense').addEventListener('click', () => {
  currentType = 'expense';
  document.getElementById('type-expense').classList.add('active');
  document.getElementById('type-income').classList.remove('active');
});
document.getElementById('type-income').addEventListener('click', () => {
  currentType = 'income';
  document.getElementById('type-income').classList.add('active');
  document.getElementById('type-expense').classList.remove('active');
});

document.getElementById('expense-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const desc = document.getElementById('exp-desc').value.trim();
  const amount = parseFloat(document.getElementById('exp-amount').value);
  const category = document.getElementById('exp-category').value;
  const date = document.getElementById('exp-date').value;

  if (!desc || !amount || !date) { showToast('Please fill all fields', 'error'); return; }
  if (amount <= 0) { showToast('Amount must be positive', 'error'); return; }

  const btn = document.querySelector('#expense-form .btn-primary');
  btn.disabled = true;
  btn.textContent = 'Saving…';

  try {
    const tx = await apiFetch('/transactions', {
      method: 'POST',
      body: JSON.stringify({ desc, amount, category, date, type: currentType })
    });
    transactions.unshift(tx);
    renderTransactions();
    updateDashboard();
    document.getElementById('expense-form').reset();
    document.getElementById('exp-date').valueAsDate = new Date();
    showToast(`${currentType === 'income' ? 'Income' : 'Expense'} added!`);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Add Transaction';
  }
});

// ===== RENDER TRANSACTIONS =====
function renderTransactions() {
  const filterCat = document.getElementById('filter-category').value;
  const filterType = document.getElementById('filter-type').value;

  let filtered = transactions.filter(tx => {
    if (filterCat !== 'all' && tx.category !== filterCat) return false;
    if (filterType !== 'all' && tx.type !== filterType) return false;
    return true;
  });

  renderTxList(document.getElementById('all-transactions'), filtered, true);
  renderTxList(document.getElementById('dash-transactions'), transactions.slice(0, 8), false);
}

function renderTxList(container, txList, showDelete) {
  if (!txList.length) {
    container.innerHTML = '<div class="empty-state"><p>No transactions here yet.</p></div>';
    return;
  }
  container.innerHTML = txList.map(tx => `
    <div class="transaction-item" id="tx-${tx.id}">
      <div class="tx-icon">${CATEGORY_ICONS[tx.category] || '📦'}</div>
      <div class="tx-info">
        <div class="tx-desc">${escapeHtml(tx.desc)}</div>
        <div class="tx-meta">${tx.category} · ${formatDate(tx.date)}</div>
      </div>
      <div class="tx-amount ${tx.type}">${tx.type === 'income' ? '+' : '-'}${fmt(tx.amount)}</div>
      ${showDelete ? `
        <button class="tx-delete" onclick="deleteTransaction(${tx.id})" title="Delete">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3 6 5 6 21 6"/>
            <path d="M19 6l-1 14H6L5 6"/>
            <path d="M10 11v6M14 11v6"/>
            <path d="M9 6V4h6v2"/>
          </svg>
        </button>` : ''}
    </div>
  `).join('');
}

function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

window.deleteTransaction = async function (id) {
  const el = document.getElementById('tx-' + id);
  if (el) { el.style.opacity = '0.4'; el.style.pointerEvents = 'none'; }
  try {
    await apiFetch(`/transactions/${id}`, { method: 'DELETE' });
    transactions = transactions.filter(t => t.id !== id);
    renderTransactions();
    updateDashboard();
    showToast('Transaction deleted');
  } catch (_) {
    if (el) { el.style.opacity = ''; el.style.pointerEvents = ''; }
  }
};

document.getElementById('filter-category').addEventListener('change', renderTransactions);
document.getElementById('filter-type').addEventListener('change', renderTransactions);

// ===== DASHBOARD =====
function getTotals() {
  const income = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const expense = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  return { income, expense, savings: income - expense };
}

function updateDashboard() {
  const { income, expense, savings } = getTotals();
  document.getElementById('dash-income').textContent = fmt(income);
  document.getElementById('dash-expense').textContent = fmt(expense);
  document.getElementById('dash-savings').textContent = fmt(savings);
  document.getElementById('sidebar-balance').textContent = fmt(savings);

  const taxEst = calcNewRegimeTax(income, 'below60');
  document.getElementById('dash-tax').textContent = fmt(taxEst.tax);

  renderTransactions();
  renderTrendChart();
  renderCategoryChart();
}

function getMonthlyData() {
  const months = {};
  transactions.filter(t => t.type === 'expense').forEach(t => {
    const key = t.date.slice(0, 7);
    months[key] = (months[key] || 0) + t.amount;
  });
  const sorted = Object.keys(months).sort();
  return {
    labels: sorted.map(k => {
      const [y, m] = k.split('-');
      return new Date(+y, +m - 1).toLocaleString('en-IN', { month: 'short', year: '2-digit' });
    }),
    values: sorted.map(k => months[k]),
    raw: sorted
  };
}

function getCategoryData() {
  const cats = {};
  transactions.filter(t => t.type === 'expense').forEach(t => {
    cats[t.category] = (cats[t.category] || 0) + t.amount;
  });
  return cats;
}

function destroyChart(key) {
  if (charts[key]) { charts[key].destroy(); charts[key] = null; }
}

const CHART_COLORS = [
  '#6c63ff', '#10b981', '#f59e0b', '#ef4444', '#3b82f6',
  '#ec4899', '#8b5cf6', '#06b6d4', '#f97316', '#84cc16', '#14b8a6', '#a855f7'
];

function renderTrendChart() {
  const { labels, values } = getMonthlyData();
  destroyChart('trend');
  const ctx = document.getElementById('trendChart').getContext('2d');
  charts.trend = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels.length ? labels : ['No data'],
      datasets: [{
        label: 'Monthly Expenses',
        data: values.length ? values : [0],
        borderColor: '#6c63ff',
        backgroundColor: 'rgba(108,99,255,0.12)',
        fill: true, tension: 0.4,
        pointBackgroundColor: '#6c63ff', pointBorderColor: '#fff',
        pointRadius: 5, pointHoverRadius: 7,
      }]
    },
    options: chartDefaults({ prefix: '₹' })
  });
}

function renderCategoryChart() {
  const cats = getCategoryData();
  const labels = Object.keys(cats);
  const values = Object.values(cats);
  destroyChart('cat');
  const ctx = document.getElementById('categoryChart').getContext('2d');
  charts.cat = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels.length ? labels : ['No expenses'],
      datasets: [{ data: values.length ? values : [1], backgroundColor: CHART_COLORS, borderWidth: 0, hoverOffset: 6 }]
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      plugins: {
        legend: { position: 'bottom', labels: { color: '#94a3b8', font: { size: 11 }, padding: 12, boxWidth: 12 } },
        tooltip: { callbacks: { label: (ctx) => ` ${ctx.label}: ${fmt(ctx.raw)}` } }
      },
      cutout: '65%'
    }
  });
}

function chartDefaults({ prefix = '' } = {}) {
  return {
    responsive: true, maintainAspectRatio: true,
    plugins: {
      legend: { labels: { color: '#94a3b8', font: { size: 11 } } },
      tooltip: { callbacks: { label: (ctx) => ` ${ctx.dataset.label}: ${prefix}${Number(ctx.raw).toLocaleString('en-IN')}` } }
    },
    scales: {
      x: { ticks: { color: '#64748b', font: { size: 11 } }, grid: { color: 'rgba(255,255,255,0.04)' } },
      y: {
        ticks: { color: '#64748b', font: { size: 11 }, callback: (v) => prefix + Number(v).toLocaleString('en-IN') },
        grid: { color: 'rgba(255,255,255,0.04)' }, beginAtZero: true
      }
    }
  };
}

// ===== PREDICTION =====
function updateInsights() {
  const { values } = getMonthlyData();
  const avg = values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
  document.getElementById('ins-avg-spend').textContent = fmt(avg);
  document.getElementById('ins-highest').textContent = fmt(values.length ? Math.max(...values) : 0);
  document.getElementById('ins-lowest').textContent = fmt(values.length ? Math.min(...values) : 0);
  const cats = getCategoryData();
  const topCat = Object.entries(cats).sort((a, b) => b[1] - a[1])[0];
  document.getElementById('ins-top-cat').textContent = topCat ? topCat[0] : 'N/A';
}

document.getElementById('predict-btn').addEventListener('click', () => {
  const months = parseInt(document.getElementById('pred-months').value);
  const inflationRate = parseFloat(document.getElementById('inflation-rate').value) / 100;
  const salaryGrowth = parseFloat(document.getElementById('salary-growth').value) / 100;
  const { values: pastValues } = getMonthlyData();

  if (!pastValues.length) { showToast('Add some expenses first!', 'error'); return; }

  const avg = pastValues.reduce((a, b) => a + b, 0) / pastValues.length;
  const trend = pastValues.length > 1 ? (pastValues[pastValues.length - 1] - pastValues[0]) / pastValues.length * 0.3 : 0;
  const now = new Date();
  const { income } = getTotals();
  const monthlyIncome = income / Math.max(pastValues.length, 1);

  const futureLabels = [], futureExpenses = [], futureIncome = [];
  for (let i = 1; i <= months; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() + i);
    futureLabels.push(d.toLocaleString('en-IN', { month: 'short', year: '2-digit' }));
    futureExpenses.push(Math.round((avg + trend * i) * Math.pow(1 + inflationRate, i / 12)));
    futureIncome.push(Math.round(monthlyIncome * Math.pow(1 + salaryGrowth, i / 12)));
  }

  const totalPredExpense = futureExpenses.reduce((a, b) => a + b, 0);
  const totalPredIncome = futureIncome.reduce((a, b) => a + b, 0);

  destroyChart('pred');
  charts.pred = new Chart(document.getElementById('predChart').getContext('2d'), {
    type: 'bar',
    data: {
      labels: futureLabels,
      datasets: [
        { label: 'Predicted Expenses', data: futureExpenses, backgroundColor: 'rgba(239,68,68,0.7)', borderRadius: 6 },
        { label: 'Predicted Income', data: futureIncome, backgroundColor: 'rgba(16,185,129,0.7)', borderRadius: 6 },
      ]
    },
    options: chartDefaults({ prefix: '₹' })
  });

  document.getElementById('pred-summary').innerHTML = `
    <h4 style="margin-bottom:12px;color:var(--text-secondary);font-size:0.85rem;text-transform:uppercase;letter-spacing:0.05em">
      Forecast — Next ${months} months
    </h4>
    <div class="pred-row"><span>Total Predicted Expenses</span><strong style="color:var(--expense-color)">${fmt(totalPredExpense)}</strong></div>
    <div class="pred-row"><span>Total Predicted Income</span><strong style="color:var(--income-color)">${fmt(totalPredIncome)}</strong></div>
    <div class="pred-row"><span>Projected Savings</span><strong style="color:var(--accent)">${fmt(totalPredIncome - totalPredExpense)}</strong></div>
    <div class="pred-row"><span>Avg Monthly Expense</span><strong>${fmt(totalPredExpense / months)}</strong></div>
    <div class="pred-row"><span>Inflation Rate</span><strong style="color:var(--accent2)">${(inflationRate * 100).toFixed(1)}% p.a.</strong></div>
    <div class="pred-row"><span>Income Growth</span><strong style="color:var(--income-color)">${(salaryGrowth * 100).toFixed(1)}% p.a.</strong></div>
  `;
  updateInsights();
});

// ===== TAX CALCULATOR =====
document.getElementById('regime-new').addEventListener('click', () => {
  currentRegime = 'new';
  document.getElementById('regime-new').classList.add('active');
  document.getElementById('regime-old').classList.remove('active');
  document.getElementById('old-regime-deductions').style.display = 'none';
});
document.getElementById('regime-old').addEventListener('click', () => {
  currentRegime = 'old';
  document.getElementById('regime-old').classList.add('active');
  document.getElementById('regime-new').classList.remove('active');
  document.getElementById('old-regime-deductions').style.display = 'block';
});

function calcNewRegimeTax(income, ageGroup) {
  const stdDeduction = 75000;
  let taxableIncome = Math.max(0, income - stdDeduction);
  const slabs = [
    { upto: 400000, rate: 0 }, { upto: 800000, rate: 0.05 }, { upto: 1200000, rate: 0.10 },
    { upto: 1600000, rate: 0.15 }, { upto: 2000000, rate: 0.20 }, { upto: 2400000, rate: 0.25 }, { upto: Infinity, rate: 0.30 }
  ];
  let tax = 0, prev = 0, slabDetail = [];
  for (const slab of slabs) {
    if (taxableIncome <= prev) break;
    const taxable = Math.min(taxableIncome, slab.upto) - prev;
    const slabTax = taxable * slab.rate;
    slabDetail.push({ from: prev, to: Math.min(taxableIncome, slab.upto), rate: slab.rate * 100, tax: slabTax });
    tax += slabTax; prev = slab.upto;
  }
  let rebate = 0;
  if (income <= 1200000) { rebate = Math.min(tax, 60000); tax = Math.max(0, tax - rebate); }
  let surcharge = 0;
  if (income > 50000000) surcharge = tax * 0.37;
  else if (income > 20000000) surcharge = tax * 0.25;
  else if (income > 10000000) surcharge = tax * 0.15;
  else if (income > 5000000) surcharge = tax * 0.10;
  surcharge = Math.round(surcharge);
  const cess = Math.round((tax + surcharge) * 0.04);
  const totalTax = tax + surcharge + cess;
  return { grossIncome: income, taxableIncome, stdDeduction, tax: Math.round(totalTax), basicTax: Math.round(tax), surcharge, cess, rebate: Math.round(rebate), effectiveRate: income > 0 ? ((totalTax / income) * 100).toFixed(2) : '0.00', slabDetail, netIncome: income - totalTax };
}

function calcOldRegimeTax(income, ageGroup, deductions) {
  const stdDeduction = 50000;
  const { ded80c, ded80d, hra, homeLoan, nps } = deductions;
  const totalDeductions = Math.min(ded80c, 150000) + Math.min(ded80d, 25000) + hra + Math.min(homeLoan, 200000) + Math.min(nps, 50000) + stdDeduction;
  let taxableIncome = Math.max(0, income - totalDeductions);
  let slabs;
  if (ageGroup === 'above80') slabs = [{ upto: 500000, rate: 0 }, { upto: 1000000, rate: 0.20 }, { upto: Infinity, rate: 0.30 }];
  else if (ageGroup === '60to80') slabs = [{ upto: 300000, rate: 0 }, { upto: 500000, rate: 0.05 }, { upto: 1000000, rate: 0.20 }, { upto: Infinity, rate: 0.30 }];
  else slabs = [{ upto: 250000, rate: 0 }, { upto: 500000, rate: 0.05 }, { upto: 1000000, rate: 0.20 }, { upto: Infinity, rate: 0.30 }];
  let tax = 0, prev = 0, slabDetail = [];
  for (const slab of slabs) {
    if (taxableIncome <= prev) break;
    const taxable = Math.min(taxableIncome, slab.upto) - prev;
    const slabTax = taxable * slab.rate;
    slabDetail.push({ from: prev, to: Math.min(taxableIncome, slab.upto), rate: slab.rate * 100, tax: slabTax });
    tax += slabTax; prev = slab.upto;
  }
  let rebate = 0;
  if (income <= 500000) { rebate = Math.min(tax, 12500); tax = Math.max(0, tax - rebate); }
  let surcharge = 0;
  if (income > 50000000) surcharge = tax * 0.37;
  else if (income > 20000000) surcharge = tax * 0.25;
  else if (income > 10000000) surcharge = tax * 0.15;
  else if (income > 5000000) surcharge = tax * 0.10;
  surcharge = Math.round(surcharge);
  const cess = Math.round((tax + surcharge) * 0.04);
  const totalTax = tax + surcharge + cess;
  return { grossIncome: income, taxableIncome, totalDeductions, stdDeduction, tax: Math.round(totalTax), basicTax: Math.round(tax), surcharge, cess, rebate: Math.round(rebate), effectiveRate: income > 0 ? ((totalTax / income) * 100).toFixed(2) : '0.00', slabDetail, netIncome: income - totalTax };
}

document.getElementById('calc-tax-btn').addEventListener('click', () => {
  const grossSalary = parseFloat(document.getElementById('gross-salary').value) || 0;
  const otherIncome = parseFloat(document.getElementById('other-income').value) || 0;
  const totalIncome = grossSalary + otherIncome;
  const ageGroup = document.getElementById('tax-age').value;
  if (totalIncome <= 0) { showToast('Please enter your income', 'error'); return; }

  let result;
  if (currentRegime === 'new') {
    result = calcNewRegimeTax(totalIncome, ageGroup);
  } else {
    result = calcOldRegimeTax(totalIncome, ageGroup, {
      ded80c: parseFloat(document.getElementById('ded-80c').value) || 0,
      ded80d: parseFloat(document.getElementById('ded-80d').value) || 0,
      hra: parseFloat(document.getElementById('ded-hra').value) || 0,
      homeLoan: parseFloat(document.getElementById('ded-home-loan').value) || 0,
      nps: parseFloat(document.getElementById('ded-nps').value) || 0,
    });
  }

  document.getElementById('tax-breakdown').innerHTML = `
    <div class="tax-row"><span class="tax-label">Gross Income</span><span class="tax-amt">${fmt(result.grossIncome)}</span></div>
    <div class="tax-row"><span class="tax-label">Standard Deduction</span><span class="tax-amt">- ${fmt(result.stdDeduction)}</span></div>
    ${currentRegime === 'old' && result.totalDeductions > result.stdDeduction ? `<div class="tax-row"><span class="tax-label">Other Deductions</span><span class="tax-amt">- ${fmt(result.totalDeductions - result.stdDeduction)}</span></div>` : ''}
    <div class="tax-row"><span class="tax-label">Taxable Income</span><span class="tax-amt">${fmt(result.taxableIncome)}</span></div>
    <div class="tax-row"><span class="tax-label">Basic Tax</span><span class="tax-amt">${fmt(result.basicTax)}</span></div>
    ${result.rebate > 0 ? `<div class="tax-row"><span class="tax-label">Rebate u/s 87A</span><span class="tax-amt" style="color:var(--accent3)">- ${fmt(result.rebate)}</span></div>` : ''}
    ${result.surcharge > 0 ? `<div class="tax-row"><span class="tax-label">Surcharge</span><span class="tax-amt">${fmt(result.surcharge)}</span></div>` : ''}
    <div class="tax-row"><span class="tax-label">Health & Edu. Cess (4%)</span><span class="tax-amt">${fmt(result.cess)}</span></div>
    <div class="tax-row total"><span class="tax-label">Total Tax Liability</span><span class="tax-amt">${fmt(result.tax)}</span></div>
    <div class="tax-row net"><span class="tax-label">Net Take-Home Income</span><span class="tax-amt">${fmt(result.netIncome)}</span></div>
    <div class="tax-row"><span class="tax-label">Effective Tax Rate</span><span class="tax-amt">${result.effectiveRate}%</span></div>
  `;

  destroyChart('tax');
  charts.tax = new Chart(document.getElementById('taxChart').getContext('2d'), {
    type: 'doughnut',
    data: {
      labels: ['Net Income', 'Basic Tax', 'Cess', ...(result.surcharge > 0 ? ['Surcharge'] : [])],
      datasets: [{
        data: [result.netIncome, result.basicTax, result.cess, ...(result.surcharge > 0 ? [result.surcharge] : [])],
        backgroundColor: ['#10b981', '#6c63ff', '#f59e0b', '#ef4444'],
        borderWidth: 0, hoverOffset: 6
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      plugins: {
        legend: { position: 'bottom', labels: { color: '#94a3b8', font: { size: 11 }, padding: 14, boxWidth: 12 } },
        tooltip: { callbacks: { label: (ctx) => ` ${ctx.label}: ${fmt(ctx.raw)}` } }
      },
      cutout: '60%'
    }
  });

  const slabCard = document.getElementById('slab-table-card');
  slabCard.style.display = 'block';
  document.getElementById('slab-table').innerHTML = `<div class="slab-table"><table>
    <thead><tr><th>Income Slab</th><th>Rate</th><th>Tax</th></tr></thead>
    <tbody>
      ${result.slabDetail.map(s => `
        <tr ${s.tax > 0 ? 'class="active-slab"' : ''}>
          <td>${fmt(s.from)} – ${s.to === Infinity ? 'Above' : fmt(s.to)}</td>
          <td>${s.rate}%</td>
          <td>${fmt(s.tax)}</td>
        </tr>`).join('')}
    </tbody>
  </table></div>`;
  showToast('Tax calculated!');
});

// ===== INVESTMENT =====
document.querySelectorAll('.inv-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.inv-tab').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.inv-content').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('inv-' + btn.dataset.inv).classList.add('active');
  });
});

// SIP
document.getElementById('calc-sip-btn').addEventListener('click', () => {
  const monthly = parseFloat(document.getElementById('sip-monthly').value) || 0;
  const rate = parseFloat(document.getElementById('sip-rate').value) || 0;
  const years = parseInt(document.getElementById('sip-years').value) || 0;
  if (!monthly || !rate || !years) { showToast('Fill all SIP fields', 'error'); return; }
  const r = rate / 100 / 12, n = years * 12;
  const total = monthly * ((Math.pow(1 + r, n) - 1) / r) * (1 + r);
  const invested = monthly * n;
  const returns = total - invested;
  document.getElementById('sip-result').style.display = 'flex';
  document.getElementById('sip-invested').textContent = fmt(invested);
  document.getElementById('sip-returns').textContent = fmt(returns);
  document.getElementById('sip-total').textContent = fmt(total);
  document.getElementById('sip-gain').textContent = ((returns / invested) * 100).toFixed(1) + '%';
  const yL = [], yI = [], yV = [];
  for (let y = 1; y <= years; y++) { const ni = y * 12; const v = monthly * ((Math.pow(1 + r, ni) - 1) / r) * (1 + r); yL.push('Yr ' + y); yI.push(Math.round(monthly * ni)); yV.push(Math.round(v)); }
  destroyChart('sip');
  charts.sip = new Chart(document.getElementById('sipChart').getContext('2d'), {
    type: 'line', data: {
      labels: yL, datasets: [
        { label: 'Portfolio Value', data: yV, borderColor: '#6c63ff', backgroundColor: 'rgba(108,99,255,0.15)', fill: true, tension: 0.4, pointRadius: 3 },
        { label: 'Amount Invested', data: yI, borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.08)', fill: true, tension: 0.4, pointRadius: 3 }
      ]
    }, options: chartDefaults({ prefix: '₹' })
  });
  showToast('SIP calculated!');
});

// FD
document.getElementById('calc-fd-btn').addEventListener('click', () => {
  let principal = parseFloat(document.getElementById('fd-principal').value) || 0;
  let rate = parseFloat(document.getElementById('fd-rate').value) || 0;
  const years = parseInt(document.getElementById('fd-years').value) || 0;
  if (document.getElementById('fd-type').value === 'senior') rate += 0.5;
  if (!principal || !rate || !years) { showToast('Fill all FD fields', 'error'); return; }
  const r = rate / 100 / 4, n = years * 4;
  const maturity = principal * Math.pow(1 + r, n);
  const interest = maturity - principal;
  document.getElementById('fd-result').style.display = 'flex';
  document.getElementById('fd-prin-display').textContent = fmt(principal);
  document.getElementById('fd-interest').textContent = fmt(interest);
  document.getElementById('fd-maturity').textContent = fmt(maturity);
  document.getElementById('fd-yield').textContent = ((maturity / principal - 1) / years * 100).toFixed(2) + '% p.a.';
  const yL = [], yV = [];
  for (let y = 0; y <= years; y++) { yL.push('Yr ' + y); yV.push(Math.round(principal * Math.pow(1 + r, y * 4))); }
  destroyChart('fd');
  charts.fd = new Chart(document.getElementById('fdChart').getContext('2d'), {
    type: 'bar', data: { labels: yL, datasets: [{ label: 'FD Value', data: yV, backgroundColor: '#f59e0b', borderRadius: 6 }] }, options: chartDefaults({ prefix: '₹' })
  });
  showToast('FD calculated!');
});

// PPF
document.getElementById('calc-ppf-btn').addEventListener('click', () => {
  const annual = parseFloat(document.getElementById('ppf-annual').value) || 0;
  const rate = parseFloat(document.getElementById('ppf-rate').value) || 0;
  const years = parseInt(document.getElementById('ppf-years').value) || 15;
  if (!annual || !rate) { showToast('Fill all PPF fields', 'error'); return; }
  if (annual > 150000) { showToast('PPF limit is ₹1,50,000', 'error'); return; }
  const r = rate / 100; let balance = 0;
  const yL = [], yB = [], yI = [];
  for (let y = 1; y <= years; y++) { balance = (balance + annual) * (1 + r); yL.push('Yr ' + y); yB.push(Math.round(balance)); yI.push(annual * y); }
  const invested = annual * years, interest = balance - invested;
  document.getElementById('ppf-result').style.display = 'flex';
  document.getElementById('ppf-invested').textContent = fmt(invested);
  document.getElementById('ppf-interest').textContent = fmt(interest);
  document.getElementById('ppf-maturity').textContent = fmt(balance);
  document.getElementById('ppf-taxsaved').textContent = fmt(Math.min(annual, 150000) * 0.30);
  destroyChart('ppf');
  charts.ppf = new Chart(document.getElementById('ppfChart').getContext('2d'), {
    type: 'line', data: {
      labels: yL, datasets: [
        { label: 'PPF Balance', data: yB, borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.12)', fill: true, tension: 0.4, pointRadius: 3 },
        { label: 'Amount Invested', data: yI, borderColor: '#6c63ff', backgroundColor: 'rgba(108,99,255,0.06)', fill: true, tension: 0.4, borderDash: [5, 5], pointRadius: 3 }
      ]
    }, options: chartDefaults({ prefix: '₹' })
  });
  showToast('PPF calculated!');
});

// GOAL PLANNER
document.getElementById('calc-goal-btn').addEventListener('click', () => {
  const targetAmount = parseFloat(document.getElementById('goal-amount').value) || 0;
  const years = parseInt(document.getElementById('goal-years').value) || 0;
  const rate = parseFloat(document.getElementById('goal-rate').value) || 0;
  const currentSavings = parseFloat(document.getElementById('current-savings').value) || 0;
  const goalName = document.getElementById('goal-name').value || 'My Goal';
  if (!targetAmount || !years || !rate) { showToast('Fill all Goal fields', 'error'); return; }
  const r = rate / 100 / 12, n = years * 12;
  const fvCurrentSavings = currentSavings * Math.pow(1 + r, n);
  const remainingTarget = Math.max(0, targetAmount - fvCurrentSavings);
  const monthlySip = remainingTarget > 0 ? remainingTarget * r / (Math.pow(1 + r, n) - 1) / (1 + r) : 0;
  const totalInvested = monthlySip * n + currentSavings;
  const projectedCorpus = monthlySip * ((Math.pow(1 + r, n) - 1) / r) * (1 + r) + fvCurrentSavings;
  document.getElementById('goal-result').style.display = 'flex';
  document.getElementById('goal-sip').textContent = fmt(Math.ceil(monthlySip));
  document.getElementById('goal-total-invest').textContent = fmt(totalInvested);
  document.getElementById('goal-corpus').textContent = fmt(projectedCorpus);
  document.getElementById('goal-returns').textContent = fmt(projectedCorpus - totalInvested);
  const yL = [], yCS = [], yGR = [];
  for (let y = 1; y <= years; y++) { const ni = y * 12; const v = monthlySip * ((Math.pow(1 + r, ni) - 1) / r) * (1 + r) + currentSavings * Math.pow(1 + r, ni); yL.push('Yr ' + y); yCS.push(Math.round(monthlySip * ni + currentSavings)); yGR.push(Math.round(v)); }
  destroyChart('goal');
  charts.goal = new Chart(document.getElementById('goalChart').getContext('2d'), {
    type: 'line', data: {
      labels: yL, datasets: [
        { label: `${goalName} Target`, data: Array(years).fill(targetAmount), borderColor: '#ef4444', borderDash: [6, 4], pointRadius: 0, fill: false },
        { label: 'Projected Corpus', data: yGR, borderColor: '#6c63ff', backgroundColor: 'rgba(108,99,255,0.12)', fill: true, tension: 0.4, pointRadius: 3 },
        { label: 'Total Invested', data: yCS, borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.06)', fill: true, tension: 0.1, pointRadius: 3 }
      ]
    }, options: chartDefaults({ prefix: '₹' })
  });
  showToast('Goal plan created!');
});

// ===== INIT =====
loadTransactions();   // fetch from Flask API on page load
